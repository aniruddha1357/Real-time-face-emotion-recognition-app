const esm = require('esm')(module);

module.exports = esm('./index.js');
